/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 *
 * @author Alejandro
 */
public class Utility {
    
    public static double distanciaGeo(double latitud1, double longitud1, double latitud2, double longitud2){
        final int R = 6378;
        double difLatitud = (Math.PI/180)*(latitud1 - latitud2);
        double difLongitud = (Math.PI/180)*(longitud2 - longitud1);
        double a = Math.pow(Math.sin(difLatitud/2),2)+(Math.cos(latitud1)*Math.cos(latitud2)*Math.pow(Math.sin(difLongitud/2), 2));
        double c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double distancia = R*c;
        return distancia;
    }
    
    
    //crear clase que pase de String fecha a LocalDate 
    public static LocalDate stringAFecha(String fechaString){
        LocalDate localDate = LocalDate.parse(fechaString);
        return localDate;
    }
    
    
    public static LocalDate consultarFecha(){
        LocalDate localDate = null;
        boolean existeError;
        Scanner sc = new Scanner(System.in);
        do{
            try{
                System.out.println("Dia (dd):");
                String dia = sc.nextLine();
                System.out.println("Mes (mm):");
                String mes = sc.nextLine();
                System.out.println("Año (yyyy):");
                String year = sc.nextLine();
                String fechaString = year+"-"+mes+"-"+dia;
                localDate = LocalDate.parse(fechaString);
                existeError = false;
            }catch(DateTimeParseException error){
                System.out.println("Ingrese la fecha correctamente");
                existeError = true;
            }
        }while(existeError);
        return localDate;
    }
    
}

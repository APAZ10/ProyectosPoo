/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gyerent;

import java.time.LocalDate;
import utility.Utility;

/**
 *
 * @author Wacho1
 */
public class reporteFechas {
    
    public reporteFechas() {     
    }
    
    public void diferenciaDias (LocalDate maxd1,LocalDate mind2, Reporte r){
        if(r.getRegistros().isEmpty()){
            System.out.println("no hay registros\n");
        }else{
            for (String registro : r.getRegistros()) {
                String[] partes= registro.split(" ");
                String fecha= partes[0];
                LocalDate fechaDate = Utility.stringAFecha(fecha);
                if((fechaDate.isAfter(mind2)||fechaDate.isEqual(mind2)) && (fechaDate.isBefore(maxd1)||fechaDate.isEqual(maxd1))){
                    System.out.println(registro);
                }
            }    
        }
    }
   
}